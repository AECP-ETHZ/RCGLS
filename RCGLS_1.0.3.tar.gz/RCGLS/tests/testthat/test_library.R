test_that("load RCGLS", {
  library(RCGLS)
})
