library(testthat)
library(RCGLS)

test_check("RCGLS")
